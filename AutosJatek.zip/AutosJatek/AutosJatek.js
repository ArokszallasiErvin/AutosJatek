const prompt = require(`prompt-sync`)()

class Cars {
    constructor(colour) {
        this.colour = colour
        this.speed = 0
        this.handbreak = 1
    }

speedUp(){
    console.log("speed up")
    if (this.handbreak == 0) {
        this.speed++
    } else {
        console.log("Warning the handbreak is pulled up! Release it before you start! ")
    }
   
}
speedDown(){
    console.log("speed down")
    if (this.speed > 0) {
        this.speed--
    }
}
handbreakUp(){
    console.log("handbreak up")
    this.handbreak = 1
    this.speed = 0
}
handbreakDown(){
    console.log("handbreak down")
    this.handbreak = 0

}
status(){
    console.log(this.colour, "car`s current speed is: ", this.speed)

}
}

car1 = new Cars ("blue")

var userOption = 3 

while(userOption!=6) {
    userOption = parseInt(prompt("What would you like to do?\n\t1 add more speed\n\t2 reduce speed\n\t3 pull up the handbreak\n\t4 push handbreak down\n\t5 print the speed status\n\t6 exit from the game\n"))
if (userOption == 1){
    car1.speedUp()
}
if (userOption == 2){
    car1.speedDown()
}
if (userOption == 3){
    car1.handbreakUp()
}
if (userOption == 4){
    car1.handbreakDown()
} 
if (userOption == 5) {
    car1.status()
}
}

console.log("See you next time")

